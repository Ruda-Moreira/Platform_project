#include "ofApp.h"

#define PLAYERSIZE 15
#define TIRO 8

//declarando estado de jogo
string game_state;
//VARI�VEL R DEMOREI PRA TE ENCONTRAR SUA LINDA
int r = 0;

//Struct Player
struct Player
{
	float posX, posY;
	int animaR = 0, animaL = 0;
	bool walkL = false, walkR = true, jump = false, tiro;

};


float tiroX, tiroY;
bool keyLeft, keyRight, keyUp;

//declarando Struct Player 
Player player;


//--------------------------------------------------------------
void ofApp::setup() {

	P1.load("images/P1.png");
	P2.load("images/P2.png");
	P3.load("images/P3.png");
	P4.load("images/P4.png");
	P5.load("images/P5.png");
	P6.load("images/P6.png");
	P7.load("images/P7.png");
	P8.load("images/P8.png");

	//estado de jogo
	game_state = "game";

	//Player position
	player.posX = 200;
	player.posY = 300;

}

//--------------------------------------------------------------
void ofApp::update() {
	ofSleepMillis(10);/*Lara, isso aqui � porque em cada PC roda em uma velocidade diferente.
					  Se ficar muito lento, pode apagar ou diminuir o n�mero.*/
	
#pragma region PlayerMove
	if (game_state == "game") {
		if (keyLeft) {
			player.posX -= 5.0;
			player.animaL++;
			player.walkL = true;
			player.walkR = false;
		}

		if (keyRight) {
			player.posX += 5.0;
			player.animaR++;
			player.walkL = false;
			player.walkR = true;
		}
		if (keyUp) {
			if (r <= 40) {
				player.posY -= 20 - r;
				r++;
			}
			else {
				keyUp = false;
				r = 0;
			}
		}
		if (player.tiro) {
			tiroX = tiroX + 1;
		}
	}
#pragma endregion
}
//???????????????????????????????????????
//--------------------------------------------------------------
void ofApp::draw() {

	if (player.tiro) {
		for (int i = 0; i < TIRO; i++) {
			ofDrawCircle(tiroX, tiroY + PLAYERSIZE/2, 5);
		}
	}

	//O c�digo desse pulo t� bem fajuto, vai ter que fazer de novo
#pragma region PlayerJump
	if (keyUp) {
		if (player.walkR) {
			P2.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.walkL) {
			P5.draw(player.posX, player.posY, PLAYERSIZE);
		}
	}
#pragma endregion
	//N�o sei se tem um jeito certo de fazer anima��o. Eu fiz assim e deu certo, mas fique � vontade pra mudar.
#pragma region PlayerWalkRight
	if (player.walkR && keyUp == false) {
		if (player.animaR == 0) {
			P1.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaR <= 10 && player.animaR > 0) {
			P2.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaR <= 20 && player.animaR > 10) {
			P1.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaR <= 30 && player.animaR > 20) {
			P3.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaR >= 30) {
			player.animaR = 0;
			P1.draw(player.posX, player.posY, PLAYERSIZE);
		}
	}
#pragma endregion
#pragma region PlayerWalkLeft

	if (player.walkL && keyUp == false) {
		if (player.animaL == 0) {
			P4.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaL <= 10 && player.animaL > 0) {
			P5.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaL <= 20 && player.animaL > 10) {
			P4.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaL <= 30 && player.animaL > 20) {
			P6.draw(player.posX, player.posY, PLAYERSIZE);
		}
		if (player.animaL >= 30) {
			player.animaL = 0;
			P4.draw(player.posX, player.posY, PLAYERSIZE);
		}
	}
#pragma endregion

	//A� falta fazer ele atirar e rolar. Acho que o c�digo pra rolar � quase o mesmo do que pra andar, s� que com sprites diferentes.
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

	//pegando input
	//aqui sim vc t� checando o input e setando ele pra verdadeiro caso ele esteja pressionado
	if (game_state == "game")
	{
		if (OF_KEY_LEFT) {
			keyLeft = true;
		}
		if (OF_KEY_RIGHT) {
			keyRight = true;
		}
		if (OF_KEY_UP && player.jump == false) {
			keyUp = true;
			player.jump = true;
		}
		if (GLFW_KEY_SPACE) {
			player.tiro = true;
			tiroX = player.posX;
			tiroY = player.posY;
		}
	}

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

	//pegando input
	//na real aqui vc t� setando que se o bot�o n�o estiver pressionado ele n�o vai estar se movimentando
	if (game_state == "game") {
		if (OF_KEY_LEFT) {
			keyLeft = false;
			player.animaL = 0;
		}
		if (OF_KEY_RIGHT) {
			keyRight = false;
			player.animaR = 0;
		}
		if (OF_KEY_UP) {
			player.jump = false;
		}
		if (GLFW_KEY_SPACE) {
			player.tiro = false;
		}
	}
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}